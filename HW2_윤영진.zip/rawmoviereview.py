import csv
class RawMovieReview:

    def __init__(self,file_name = 'samples.csv'):
        self._dataset = []
        with open(file_name, 'r', encoding='utf-8-sig') as fd:
            reader = csv.reader(fd)
            for row in reader:
                self._dataset.append(row)
    def __getitem__(self,index):
        if index > len(self._dataset):
            raise IndexError()
        return tuple((self._dataset[index+1][0],self._dataset[index+1][1],int(self._dataset[index+1][2])))
    def __len__(self):
        return len(self._dataset)-1

dataset = RawMovieReview()