from bs4 import BeautifulSoup
import requests
import time
import random
import csv

review_data = []
need_data = 1000

for page_num in range(300):
    URL = f'https://movie.naver.com/movie/point/af/list.naver?&page={page_num+1}'
    response = requests.get(URL)
    
    soup = BeautifulSoup(#
        response.text,
        'html.parser'
    )

    netizen_review = soup.find_all("td",{"class":"title"})

    for review in netizen_review:
        sentence = review.find("a",{"class":"report"}).get("onclick").split("', '")[2]
        if sentence != "":
            title = review.find("a",{'class':'movie color_b'}).get_text()
            score = review.find("em").get_text()
            review_data.append([title,sentence,int(score)])
            need_data -= 1

    if need_data<0:
        break
    time.sleep(random.uniform(0.5,1))
  

with open('samples.csv', 'w', encoding = 'utf8', newline='') as fd:
    writer = csv.writer(fd)
    writer.writerow(['movie','sentence','score'])
    writer.writerows(review_data)




    
