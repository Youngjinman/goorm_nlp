from asyncio import FastChildWatcher
from mimetypes import init
from rawmoviereview import RawMovieReview


class MovieReview(RawMovieReview):
    def __init__(self, score_threadhold:int, file_name='samples.csv'):
        super().__init__(file_name)
        self.score_threadhold = score_threadhold

    def __getitem__(self,index):
        if super().__getitem__(index)[2] >= self.score_threadhold:
            return (self._dataset[index+1][1].strip(), True)
        return (self._dataset[index+1][1].strip(),False)

movie = MovieReview(5)

